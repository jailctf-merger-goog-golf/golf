import re
p=lambda g:exec("s=str(g);g[::-1]=zip(*eval(re.sub('0(?=.{%r}3.{%r}3)'%(*b'%Kq9V'[s.count('3')//8::3],),'8',s)));"*4)or g