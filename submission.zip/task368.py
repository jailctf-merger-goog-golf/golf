def p(g):
 *b,=a=sum(g,[]);i=k=100
 while i:i-=1;a[i]==5!=exec("if b[k:=k-1]%5:g+=k,;a[i+k-g[10]]=a[k]\n"*k)
 return*zip(*[iter(a)]*10),