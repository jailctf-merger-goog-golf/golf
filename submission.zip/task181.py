def p(g):
 for x in g[:3]:d=6>>g[3][3];x[d:d+3]=x[5:2:-1]
 return g