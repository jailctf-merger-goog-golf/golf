import re
p=lambda g,i=7:-i*g or p([*zip(*eval(re.sub("\d(?=(?=(.)+"+"(.%r)+(?<=0))"%{sum(len(y)*3+8for*y,x in g if{*y}=={x,0})}*2,r"\1",f'{g}'))[::335%~i|1])],i-1)