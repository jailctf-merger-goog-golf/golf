f=lambda t:t[exec("t[:]=zip(*t[sum(t[0])in t[0]:][::-1]);"*82):]
p=lambda g:eval(f"[[r&n%~n\nfor r,n in zip(r,n[::{-~len(n:=f(f(g)[4:]))//len(r:=f(g[:4]))}])]#"*2)