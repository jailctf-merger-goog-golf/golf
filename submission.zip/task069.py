def p(g):
 *b,=a=sum(g,[]);i=j=100
 while i:i-=1;a[i]==8==exec("if b[j:=j-1]%8:g+=j,;a[i-g[10]+j]=b[j];a[j]=0\n"*j)
 return*zip(*[iter(a)]*10),