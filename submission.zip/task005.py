import re
p=lambda g:eval(re.sub(f"0(?=(?=(.)+{'(.{2%%d})+(?<=%s))'%max(str(29**14),key=f'{g}'.count)*2}|"*2%(*b"<<HH",),r"\1\4",f'{*zip(*g[147:]or p(g*2)),}'))[::-1]