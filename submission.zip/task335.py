S=sum
p=lambda g,s=6:[[j^(9<9|(s:=s+S(i)*S(a))%3|S(i)>3<S(a)|~s%9)*4>>j*9for*a,j in zip(*g,i)]for i in g]