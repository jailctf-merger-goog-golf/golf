def p(g,*c):
 f,*d=0,
 for r in*zip(*g),c:g,d,*c=any(r)*((*r,5).index(5),d,*c,r)or(g,d+[[sum({*sum(c*d,r)}-{5})for d in j*f][f-g:][:3]for j in c]);f+=g
 return*zip(*d),