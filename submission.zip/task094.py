import re
p=lambda g,x=0:eval(re.sub("8(?=[^(]*+[^)]*1.{46}1, 1)","6",f'{*zip(*x or p(g,g)),}'))