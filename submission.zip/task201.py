import re
p=lambda t:[v:=[4,*[0]*len(s:=eval('[*zip(*filter(any,'*2+re.sub('(4(.)*?, 4)',r"*[t.append(\2)]*len([\1])",f"{*zip(*t),}")+'))]'*2)),4],*zip([t[-2]]*9,*s[::1|-(t[-1]in s[0])],t[14:]*9),v]