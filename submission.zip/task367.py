import re
p=lambda g,i=89:g*-i or p(eval(re.sub('0,|4, (?=0|5.%r5.{5}5)'%{len(g)*3-2},'i//89*4,',f"{*zip(*g[::i%-3|1]),}")),i-1)