import re
p=lambda g,i=-63:g*i or p(eval(re.sub('8'+'(?=.{28,31}3)|3'*(j:=i%20),'3-j//19*((C:=s.count)("3")*3+C("0"))//50',s:=f'{*zip(*g),}',j+1))[::-1],i+1)